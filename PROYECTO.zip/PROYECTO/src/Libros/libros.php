<?php
class Libro {
    public $id_libro;
    public $n_libro;
    public $author;
    public $publication_year;
    public $isbn;


    // Constructor para crear un objeto Task a partir de un array de datos
    public function __construct($data) {
        $this->id_libro = $data['id_libro'];
        $this->n_libro = $data['n_libro'];
        $this->author = $data['author'];
        $this->publication_year = $data['publication_year'];
        $this->isbn = $data['isbn'];
    }

    // Aquí podrían añadirse métodos adicionales relacionados con una tarea individual
}