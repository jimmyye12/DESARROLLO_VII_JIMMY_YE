<?php
$path = __DIR__ . '/database/migrations';
echo "Ruta de migraciones: $path\n\n";

if (!is_dir($path)) {
    echo "ERROR: la carpeta no existe.\n";
    exit;
}

$files = scandir($path);
foreach ($files as $f) {
    if (pathinfo($f, PATHINFO_EXTENSION) !== 'sql') continue;
    $full = $path . '/' . $f;
    echo "Archivo: $f\n";
    echo " - Existe? " . (file_exists($full) ? 'sí' : 'no') . "\n";
    echo " - Tamaño: " . (file_exists($full) ? filesize($full) : '0') . " bytes\n";
    $content = file_get_contents($full);
    if ($content === false) {
        echo " - file_get_contents devolvió false\n";
    } else {
        $trimmed = trim($content);
        echo " - Contenido vacío? " . ($trimmed === '' ? 'SÍ' : 'NO') . "\n";
        // imprime las primeras 250 caracteres para inspección
        echo " - Primeros 250 caracteres:\n";
        echo substr($content, 0, 250) . "\n";
    }
    echo str_repeat("-",40) . "\n";
}
